package blastP;
import uk.ac.ebi.uniprot.dataservice.client.alignment.blast.BlastResult;
import uk.ac.ebi.uniprot.dataservice.client.alignment.blast.UniProtHit;

public class BlastExample {
	public static void main(String[] args) {
			String sequence = ">seq1\nnQktalhdPITtiAMtGdeGeIkIMlelypnkVHIyKQPETqqqHysaIitWYGtGldAf\r\n"
					+ "TAedLdSriENLLekDqFTVePLSVdtdCnPHqKNkFrCnGvgIDHRllNNesnqgKIwA\r\n"
					+ "WwCsaFNCATNPDDQvkCKKvGaadQsAnfTtvLeWvPWvirikKgYykEMvNvpkkkPV\r\n"
					+ "TmMTYRQrIttKiEasTnvSgQttfhFQtvaDFgeCfNCrWitCqntEgLKkQqHWKlrR\r\n"
					+ "SCdGsafyncFEGayELtlQyLQnnrqffScHCagPvdfPfCGDaSvFCPQdiGArrQWs\r\n"
					+ "FqknPvtaq";
			float mineval = 0.00000000000000000001f;
			int maxseq = 10;
			String matrix = "BLOSUM62";
			String filename = "temp_output.tsv";
			BlastResult<UniProtHit> uniprotblastResult = BlastpSearch.runUniprotBlast(sequence);
			BlastpSearch.writeUniprotBlastOutput(uniprotblastResult,mineval,maxseq,filename);
			
			
			BlastpSearch.runCustomBlast(sequence,mineval,maxseq,matrix);
			}
		
		
}
